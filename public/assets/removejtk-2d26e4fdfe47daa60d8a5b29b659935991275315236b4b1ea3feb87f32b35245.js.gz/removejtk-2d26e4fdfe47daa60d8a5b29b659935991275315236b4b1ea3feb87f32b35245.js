function removejtk() {
  $('.jtk-connector').remove();
  $('.jtk-endpoint').remove();
  $('.jtk-overlay').remove();  
}
;
